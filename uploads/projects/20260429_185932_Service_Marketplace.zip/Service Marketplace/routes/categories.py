from flask import Blueprint, jsonify
from models import db, Category

categories_bp = Blueprint('categories', __name__)

@categories_bp.route('/', methods=['GET'])
def get_categories():
    """
    Retrieve all service categories from the database.
    Returns a JSON list of category objects.
    """
    try:
        # Using SQLAlchemy ORM to fetch all categories
        # This is cleaner and more maintainable than raw SQL
        categories = Category.query.all()
        
        # Using the to_dict() method for clean serialization
        result = [category.to_dict() for category in categories]
        
        # Return 200 OK with the list of categories
        return jsonify(result), 200
        
    except Exception as e:
        # Log the error (in a real app, use a logging library)
        # Return a 500 Internal Server Error if something goes wrong
        return jsonify({"message": f"An error occurred while fetching categories: {str(e)}"}), 500

@categories_bp.route('/<int:category_id>', methods=['GET'])
def get_category(category_id):
    """
    Retrieve a single category by its ID.
    """
    try:
        category = Category.query.get(category_id)
        if category:
            return jsonify(category.to_dict()), 200
        else:
            return jsonify({"message": "Category not found"}), 404
            
    except Exception as e:
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500