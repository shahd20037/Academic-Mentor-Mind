from flask import Blueprint, request, jsonify, current_app
from flask_sqlalchemy import SQLAlchemy
from marshmallow import Schema, fields, validate
from datetime import datetime

# Initialize SQLAlchemy (this would typically be done in your main app.py)
db = SQLAlchemy()

# Define your models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    orders = db.relationship('Order', backref='buyer', lazy=True)

    def __repr__(self):
        return f'<User {self.username}>'

class Service(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    price = db.Column(db.Float, nullable=False)
    orders = db.relationship('Order', backref='service', lazy=True)

    def __repr__(self):
        return f'<Service {self.name}>'

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey('service.id'), nullable=False)
    due_date = db.Column(db.DateTime, nullable=True)
    total_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(50), default='pending', nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Order {self.id}>'

# Define Marshmallow Schemas for validation and serialization
class OrderSchema(Schema):
    id = fields.Int(dump_only=True)
    buyer_id = fields.Int(required=True, error_messages={'required': 'Buyer ID is required.'})
    service_id = fields.Int(required=True, error_messages={'required': 'Service ID is required.'})
    due_date = fields.DateTime(allow_none=True)
    total_amount = fields.Float(required=True, validate=validate.Range(min=0.01), error_messages={'required': 'Total amount is required.'})
    status = fields.Str(dump_only=True)
    created_at = fields.DateTime(dump_only=True)

class OrderUpdateSchema(Schema):
    status = fields.Str(required=True, validate=validate.OneOf(['pending', 'processing', 'completed', 'cancelled']), error_messages={'required': 'Status is required.'})

order_schema = OrderSchema()
orders_schema = OrderSchema(many=True)
order_update_schema = OrderUpdateSchema()

orders_bp = Blueprint('orders', __name__)

@orders_bp.route('/', methods=['POST'])
def place_order():
    try:
        # Validate input data
        order_data = order_schema.load(request.json)
    except Exception as err:
        return jsonify({'message': 'Validation Error', 'errors': err.messages}), 400

    # Check if buyer and service exist
    buyer = User.query.get(order_data['buyer_id'])
    service = Service.query.get(order_data['service_id'])

    if not buyer:
        return jsonify({'message': 'Buyer not found'}), 404
    if not service:
        return jsonify({'message': 'Service not found'}), 404

    try:
        new_order = Order(
            buyer_id=order_data['buyer_id'],
            service_id=order_data['service_id'],
            due_date=order_data.get('due_date'),
            total_amount=order_data['total_amount']
        )
        db.session.add(new_order)
        db.session.commit()
        return jsonify({'message': 'Order placed successfully', 'order': order_schema.dump(new_order)}), 201
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f'Error placing order: {e}')
        return jsonify({'message': 'Internal Server Error', 'details': str(e)}), 500

@orders_bp.route('/<int:order_id>', methods=['PUT'])
def update_order(order_id):
    try:
        # Validate input data
        update_data = order_update_schema.load(request.json)
    except Exception as err:
        return jsonify({'message': 'Validation Error', 'errors': err.messages}), 400

    order = Order.query.get(order_id)

    if not order:
        return jsonify({'message': 'Order not found'}), 404

    try:
        order.status = update_data['status']
        db.session.commit()
        return jsonify({'message': 'Order updated successfully', 'order': order_schema.dump(order)}), 200
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f'Error updating order {order_id}: {e}')
        return jsonify({'message': 'Internal Server Error', 'details': str(e)}), 500
