from flask import Blueprint, request, jsonify, current_app
from flask_sqlalchemy import SQLAlchemy
from marshmallow import Schema, fields, validate
from datetime import datetime

# Initialize SQLAlchemy (this would typically be done in your main app.py)
db = SQLAlchemy()

# Define your models (re-using from previous task for context)
class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    orders = db.relationship('Order', backref='buyer', lazy=True)
    sent_messages = db.relationship('Message', foreign_keys='Message.sender_id', backref='sender', lazy=True)
    received_messages = db.relationship('Message', foreign_keys='Message.receiver_id', backref='receiver', lazy=True)

    def __repr__(self):
        return f'<User {self.username}>'

class Service(db.Model):
    __tablename__ = 'service'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    price = db.Column(db.Float, nullable=False)
    orders = db.relationship('Order', backref='service', lazy=True)

    def __repr__(self):
        return f'<Service {self.name}>'

class Order(db.Model):
    __tablename__ = 'order'
    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey('service.id'), nullable=False)
    due_date = db.Column(db.DateTime, nullable=True)
    total_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(50), default='pending', nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    messages = db.relationship('Message', backref='order', lazy=True)

    def __repr__(self):
        return f'<Order {self.id}>'

class Message(db.Model):
    __tablename__ = 'message'
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=True) # Message can be general or related to an order
    message_text = db.Column(db.Text, nullable=False)
    sent_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return f'<Message {self.id} from {self.sender_id} to {self.receiver_id}>'

# Define Marshmallow Schemas for validation and serialization
class MessageSchema(Schema):
    id = fields.Int(dump_only=True)
    sender_id = fields.Int(required=True, error_messages={'required': 'Sender ID is required.'})
    receiver_id = fields.Int(required=True, error_messages={'required': 'Receiver ID is required.'})
    order_id = fields.Int(allow_none=True)
    message_text = fields.Str(required=True, validate=validate.Length(min=1), error_messages={'required': 'Message text cannot be empty.'})
    sent_at = fields.DateTime(dump_only=True)
    is_read = fields.Bool(dump_only=True)

message_schema = MessageSchema()
messages_schema = MessageSchema(many=True)

messages_bp = Blueprint('messages', __name__)

@messages_bp.route('/', methods=['POST'])
def send_message():
    try:
        # Validate input data
        message_data = message_schema.load(request.json)
    except Exception as err:
        return jsonify({'message': 'Validation Error', 'errors': err.messages}), 400

    # Check if sender, receiver, and optionally order exist
    sender = User.query.get(message_data['sender_id'])
    receiver = User.query.get(message_data['receiver_id'])
    order = Order.query.get(message_data['order_id']) if message_data.get('order_id') else None

    if not sender:
        return jsonify({'message': 'Sender not found'}), 404
    if not receiver:
        return jsonify({'message': 'Receiver not found'}), 404
    if message_data.get('order_id') and not order:
        return jsonify({'message': 'Order not found'}), 404

    try:
        new_message = Message(
            sender_id=message_data['sender_id'],
            receiver_id=message_data['receiver_id'],
            order_id=message_data.get('order_id'),
            message_text=message_data['message_text']
        )
        db.session.add(new_message)
        db.session.commit()
        return jsonify({'message': 'Message sent successfully', 'message_details': message_schema.dump(new_message)}), 201
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f'Error sending message: {e}')
        return jsonify({'message': 'Internal Server Error', 'details': str(e)}), 500

@messages_bp.route('/order/<int:order_id>', methods=['GET'])
def get_messages_by_order(order_id):
    order = Order.query.get(order_id)
    if not order:
        return jsonify({'message': 'Order not found'}), 404

    messages = Message.query.filter_by(order_id=order_id).order_by(Message.sent_at).all()
    return jsonify(messages_schema.dump(messages)), 200

@messages_bp.route('/user/<int:user_id>', methods=['GET'])
def get_messages_by_user(user_id):
    user = User.query.get(user_id)
    if not user:
        return jsonify({'message': 'User not found'}), 404

    # Get messages where user is sender or receiver
    messages = Message.query.filter(
        (Message.sender_id == user_id) | (Message.receiver_id == user_id)
    ).order_by(Message.sent_at).all()
    return jsonify(messages_schema.dump(messages)), 200

@messages_bp.route('/<int:message_id>/read', methods=['PUT'])
def mark_message_as_read(message_id):
    message = Message.query.get(message_id)
    if not message:
        return jsonify({'message': 'Message not found'}), 404

    try:
        message.is_read = True
        db.session.commit()
        return jsonify({'message': 'Message marked as read', 'message_details': message_schema.dump(message)}), 200
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f'Error marking message {message_id} as read: {e}')
        return jsonify({'message': 'Internal Server Error', 'details': str(e)}), 500