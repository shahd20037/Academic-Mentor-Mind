from flask import Blueprint, request, jsonify, current_app
from flask_sqlalchemy import SQLAlchemy
from marshmallow import Schema, fields, validate
from datetime import datetime

# Initialize SQLAlchemy (this would typically be done in your main app.py)
db = SQLAlchemy()

# Define your models (re-using from previous tasks for context)
class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    orders = db.relationship('Order', backref='buyer', lazy=True)
    sent_messages = db.relationship('Message', foreign_keys='Message.sender_id', backref='sender', lazy=True)
    received_messages = db.relationship('Message', foreign_keys='Message.receiver_id', backref='receiver', lazy=True)
    reviews_given = db.relationship('Review', foreign_keys='Review.reviewer_id', backref='reviewer', lazy=True)
    reviews_received = db.relationship('Review', foreign_keys='Review.seller_id', backref='seller', lazy=True)

    def __repr__(self):
        return f'<User {self.username}>'

class Service(db.Model):
    __tablename__ = 'service'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    price = db.Column(db.Float, nullable=False)
    orders = db.relationship('Order', backref='service', lazy=True)
    reviews = db.relationship('Review', backref='service_reviewed', lazy=True)

    def __repr__(self):
        return f'<Service {self.name}>'

class Order(db.Model):
    __tablename__ = 'order'
    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey('service.id'), nullable=False)
    due_date = db.Column(db.DateTime, nullable=True)
    total_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(50), default='pending', nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    messages = db.relationship('Message', backref='order', lazy=True)
    review = db.relationship('Review', backref='order_reviewed', uselist=False, lazy=True) # One-to-one with Review

    def __repr__(self):
        return f'<Order {self.id}>'

class Message(db.Model):
    __tablename__ = 'message'
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=True)
    message_text = db.Column(db.Text, nullable=False)
    sent_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return f'<Message {self.id} from {self.sender_id} to {self.receiver_id}>'

class Review(db.Model):
    __tablename__ = 'review'
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), unique=True, nullable=False) # One review per order
    reviewer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey('service.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text, nullable=True)
    review_date = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Review {self.id} for Order {self.order_id}>'

# Define Marshmallow Schemas for validation and serialization
class ReviewSchema(Schema):
    id = fields.Int(dump_only=True)
    order_id = fields.Int(required=True, error_messages={'required': 'Order ID is required.'})
    reviewer_id = fields.Int(required=True, error_messages={'required': 'Reviewer ID is required.'})
    seller_id = fields.Int(required=True, error_messages={'required': 'Seller ID is required.'})
    service_id = fields.Int(required=True, error_messages={'required': 'Service ID is required.'})
    rating = fields.Int(required=True, validate=validate.Range(min=1, max=5), error_messages={'required': 'Rating (1-5) is required.'})
    comment = fields.Str(allow_none=True, validate=validate.Length(max=500))
    review_date = fields.DateTime(dump_only=True)

review_schema = ReviewSchema()
reviews_schema = ReviewSchema(many=True)

reviews_bp = Blueprint('reviews', __name__)

@reviews_bp.route('/', methods=['POST'])
def add_review():
    try:
        # Validate input data
        review_data = review_schema.load(request.json)
    except Exception as err:
        return jsonify({'message': 'Validation Error', 'errors': err.messages}), 400

    # Check if order exists and has not been reviewed yet
    order = Order.query.get(review_data['order_id'])
    if not order:
        return jsonify({'message': 'Order not found'}), 404
    if order.review: # Check if a review already exists for this order
        return jsonify({'message': 'This order has already been reviewed'}), 409 # Conflict

    # Ensure the reviewer is the buyer of the order
    if order.buyer_id != review_data['reviewer_id']:
        return jsonify({'message': 'Only the buyer of the order can leave a review'}), 403 # Forbidden

    # Ensure the seller_id and service_id match the order details
    if order.service.id != review_data['service_id']:
        return jsonify({'message': 'Service ID does not match the order'}), 400
    # Assuming seller_id is associated with the service provider, this check might need adjustment
    # based on how your 'seller' is linked to 'service'. For simplicity, let's assume the seller_id
    # provided in the review data should match the service provider if you have one.
    # For now, we'll just check if the seller_id exists as a user.
    seller = User.query.get(review_data['seller_id'])
    if not seller:
        return jsonify({'message': 'Seller not found'}), 404

    try:
        new_review = Review(
            order_id=review_data['order_id'],
            reviewer_id=review_data['reviewer_id'],
            seller_id=review_data['seller_id'],
            service_id=review_data['service_id'],
            rating=review_data['rating'],
            comment=review_data.get('comment')
        )
        db.session.add(new_review)
        db.session.commit()
        return jsonify({'message': 'Review added successfully', 'review': review_schema.dump(new_review)}), 201
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f'Error adding review: {e}')
        return jsonify({'message': 'Internal Server Error', 'details': str(e)}), 500

@reviews_bp.route('/seller/<int:seller_id>', methods=['GET'])
def get_reviews_for_seller(seller_id):
    seller = User.query.get(seller_id)
    if not seller:
        return jsonify({'message': 'Seller not found'}), 404

    reviews = Review.query.filter_by(seller_id=seller_id).order_by(Review.review_date.desc()).all()
    return jsonify(reviews_schema.dump(reviews)), 200

@reviews_bp.route('/order/<int:order_id>', methods=['GET'])
def get_review_for_order(order_id):
    order = Order.query.get(order_id)
    if not order:
        return jsonify({'message': 'Order not found'}), 404

    review = Review.query.filter_by(order_id=order_id).first()
    if not review:
        return jsonify({'message': 'Review not found for this order'}), 404

    return jsonify(review_schema.dump(review)), 200