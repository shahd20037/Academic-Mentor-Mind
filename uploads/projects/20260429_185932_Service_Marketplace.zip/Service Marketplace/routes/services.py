from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, Service, User, Category

services_bp = Blueprint('services', __name__)

@services_bp.route('/', methods=['POST'])
@jwt_required()
def create_service():
    """
    Create a new service. Requires authentication.
    The seller_id is automatically taken from the JWT token.
    """
    current_user_id = get_jwt_identity()
    data = request.get_json()
    
    if not data:
        return jsonify({"message": "Invalid JSON"}), 400

    # Required fields
    category_id = data.get('category_id')
    title = data.get('title')
    description = data.get('description')
    price = data.get('price')
    delivery_time = data.get('delivery_time')

    # Basic Validation
    if not all([category_id, title, description, price, delivery_time]):
        return jsonify({"message": "Missing required fields"}), 400

    try:
        # Check if category exists
        if not Category.query.get(category_id):
            return jsonify({"message": "Category not found"}), 404

        # Check if user is a seller
        user = User.query.get(current_user_id)
        if not user or not user.is_seller:
            return jsonify({"message": "Only registered sellers can create services"}), 403

        # Validate price and delivery time
        if float(price) <= 0:
            return jsonify({"message": "Price must be greater than 0"}), 400
        if int(delivery_time) <= 0:
            return jsonify({"message": "Delivery time must be at least 1 day"}), 400

        new_service = Service(
            seller_id=current_user_id,
            category_id=category_id,
            title=title,
            description=description,
            price=price,
            delivery_time=delivery_time,
            status='active'
        )

        db.session.add(new_service)
        db.session.commit()
        
        return jsonify({"message": "Service created successfully", "service_id": new_service.service_id}), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error creating service: {str(e)}"}), 500

@services_bp.route('/', methods=['GET'])
def list_services():
    """
    List all active services.
    Optional filtering by category_id can be added here.
    """
    try:
        category_id = request.args.get('category_id', type=int)
        
        query = Service.query.filter_by(status='active')
        
        if category_id:
            query = query.filter_by(category_id=category_id)
            
        services = query.all()
        return jsonify([service.to_dict() for service in services]), 200
        
    except Exception as e:
        return jsonify({"message": f"Error fetching services: {str(e)}"}), 500

@services_bp.route('/<int:service_id>', methods=['GET'])
def get_service(service_id):
    """
    Get details of a specific service.
    """
    try:
        service = Service.query.get(service_id)
        if service:
            return jsonify(service.to_dict()), 200
        return jsonify({"message": "Service not found"}), 404
    except Exception as e:
        return jsonify({"message": f"Error: {str(e)}"}), 500