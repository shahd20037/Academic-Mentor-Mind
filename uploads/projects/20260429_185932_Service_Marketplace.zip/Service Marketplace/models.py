from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = "Users"
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False, unique=True)
    email = db.Column(db.String(120), nullable=False, unique=True)
    password_hash = db.Column(db.String(120), nullable=False)
    full_name = db.Column(db.String(120))
    phone_number = db.Column(db.String(20))
    bio = db.Column(db.String(250))
    is_seller = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Category(db.Model):
    __tablename__ = "Categories"
    category_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, unique=True)
    description = db.Column(db.String(250))

class Service(db.Model):
    __tablename__ = "Services"
    service_id = db.Column(db.Integer, primary_key=True)
    seller_id = db.Column(db.Integer, db.ForeignKey("Users.user_id"), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey("Categories.category_id"), nullable=False)
    title = db.Column(db.String(120), nullable=False)
    description = db.Column(db.String(500), nullable=False)
    price = db.Column(db.Float, nullable=False)
    delivery_time = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(20), default="active")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Order(db.Model):
    __tablename__ = "Orders"
    order_id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey("Users.user_id"), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey("Services.service_id"), nullable=False)
    total_amount = db.Column(db.Float, nullable=False)
    order_date = db.Column(db.DateTime, default=datetime.utcnow)
    due_date = db.Column(db.DateTime)
    status = db.Column(db.String(20), default="pending")
    payment_status = db.Column(db.String(20), default="pending")

class Message(db.Model):
    __tablename__ = "Messages"
    message_id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey("Users.user_id"), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey("Users.user_id"), nullable=False)
    message_text = db.Column(db.String(500), nullable=False)
    sent_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)
    order_id = db.Column(db.Integer, db.ForeignKey("Orders.order_id"))

class Review(db.Model):
    __tablename__ = "Reviews"
    review_id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("Orders.order_id"), nullable=False)
    reviewer_id = db.Column(db.Integer, db.ForeignKey("Users.user_id"), nullable=False)
    seller_id = db.Column(db.Integer, db.ForeignKey("Users.user_id"), nullable=False)
    service_id = db.Column(db.Integer, db.ForeignKey("Services.service_id"), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    review_date = db.Column(db.DateTime, default=datetime.utcnow)
    comment = db.Column(db.String(500))