from flask import Flask, render_template, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
import os

# Initialize Flask App
app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///servixo.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'jwt_secret_key_here'

# Initialize Extensions
db = SQLAlchemy(app)
jwt = JWTManager(app)

# ----------------------------------------------------------------
# 1. Frontend Routes (Serving HTML Pages)
# ----------------------------------------------------------------

@app.route("/")
@app.route("/index.html")
def index():
    return render_template('index.html')

@app.route("/login")
@app.route("/login.html")
def login():
    return render_template('login.html')

@app.route("/buyer-dashboard")
@app.route("/buyer-dashboard.html")
def buyer_dashboard():
    return render_template('buyer-dashboard.html')

@app.route("/seller-dashboard")
@app.route("/seller-dashboard.html")
def seller_dashboard():
    return render_template('seller-dashboard.html')

@app.route("/services")
@app.route("/services.html")
def services():
    return render_template('services.html')

@app.route("/service-details")
@app.route("/service-details.html")
def service_details():
    return render_template('service-details.html')

@app.route("/add-service")
@app.route("/add-service.html")
def add_service():
    return render_template('add-service.html')

@app.route("/my-services")
@app.route("/my-services.html")
def my_services():
    return render_template('my-services.html')

@app.route("/order-history")
@app.route("/order-history.html")
def order_history():
    return render_template('order-history.html')

@app.route("/chat")
@app.route("/chat.html")
def chat():
    return render_template('chat.html')

@app.route("/earnings")
@app.route("/earnings.html")
def earnings():
    return render_template('earnings.html')

# ----------------------------------------------------------------
# 2. API Blueprints Registration
# ----------------------------------------------------------------
# Note: These assume you have separated the logic into different files 
# as shown in the PDF (e.g., users.py, services.py, etc.)

try:
    from routes.users import users_bp
    from routes.categories import categories_bp
    from routes.services import services_bp
    from routes.orders import orders_bp
    from routes.messages import messages_bp
    from routes.reviews import reviews_bp

    app.register_blueprint(users_bp, url_prefix='/api/users')
    app.register_blueprint(categories_bp, url_prefix='/api/categories')
    app.register_blueprint(services_bp, url_prefix='/api/services')
    app.register_blueprint(orders_bp, url_prefix='/api/orders')
    app.register_blueprint(messages_bp, url_prefix='/api/messages')
    app.register_blueprint(reviews_bp, url_prefix='/api/reviews')
except ImportError:
    # If files are not yet separated, this part will be skipped
    # You can also include the blueprint logic directly here if preferred
    pass

# ----------------------------------------------------------------
# 3. Database Initialization
# ----------------------------------------------------------------

@app.before_request
def create_tables():
    db.create_all()

# ----------------------------------------------------------------
# 4. Error Handlers
# ----------------------------------------------------------------

@app.errorhandler(404)
def not_found(e):
    return jsonify({"message": "Resource not found"}), 404

if __name__ == '__main__':
    # Ensure templates folder exists
    if not os.path.exists('templates'):
        os.makedirs('templates')
    
    app.run(debug=True, port=5000)