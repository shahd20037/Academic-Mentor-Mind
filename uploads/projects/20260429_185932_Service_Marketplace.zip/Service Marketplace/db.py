import pyodbc

conn = pyodbc.connect(
    'DRIVER={ODBC Driver 18 for SQL Server};'
    'SERVER=localhost;'
    'DATABASE=service_marketplace;'
    'UID=sa;'
    'PWD=your_password;'
    'TrustServerCertificate=yes;'
)