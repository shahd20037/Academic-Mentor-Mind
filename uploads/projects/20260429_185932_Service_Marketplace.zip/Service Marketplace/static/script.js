// fetch Services من الـ API
fetch('/services/')
    .then(response => response.json())
    .then(data => {
        const container = document.getElementById('services');
        data.forEach(service => {
            const div = document.createElement('div');
            div.classList.add('service');
            div.innerHTML = `
                <h3>${service.title}</h3>
                <p>${service.description}</p>
                <p>Price: $${service.price}</p>
                <p>Delivery Time: ${service.delivery_time} days</p>
            `;
            container.appendChild(div);
        });
    })
    .catch(err => console.error('Error fetching services:', err));